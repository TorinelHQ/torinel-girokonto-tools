import { describe, expect, it } from 'vitest';
import { scoreWechselReadiness } from '../src/wechsel';

describe('Wechsel readiness scoring', () => {
  it('returns neutral before any answers', () => {
    expect(scoreWechselReadiness({}).state).toBe('neutral');
  });

  it('blocks cancellation when critical steps are missing', () => {
    const result = scoreWechselReadiness({ newAccountActive: true });
    expect(result.state).toBe('red');
  });

  it('marks ready when most steps are done', () => {
    const result = scoreWechselReadiness({
      newAccountActive: true,
      salaryUpdated: true,
      standingOrdersMoved: true,
      directDebitsChecked: true,
      digitalPaymentsUpdated: true,
      cardsChecked: true,
      overdraftCleared: true,
      statementsSaved: true,
      parallelRunObserved: true,
      remainingBalanceTransferred: true
    });
    expect(result.state).toBe('green');
  });
});
