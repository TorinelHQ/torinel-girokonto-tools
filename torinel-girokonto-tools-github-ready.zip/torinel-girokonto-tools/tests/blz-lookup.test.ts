import { describe, expect, it } from 'vitest';
import { lookupBankByBlz, sampleBankDirectory } from '../src/blz';

describe('BLZ lookup', () => {
  it('finds Freisinger Bank', () => {
    const result = lookupBankByBlz('70169614', sampleBankDirectory);
    expect(result.status).toBe('found');
    expect(result.record?.bankName).toBe('Freisinger Bank eG');
  });

  it('finds VR Bank Rosenheim-Chiemsee', () => {
    const result = lookupBankByBlz('71160000', sampleBankDirectory);
    expect(result.status).toBe('found');
    expect(result.record?.bankName).toBe('VR Bank Rosenheim-Chiemsee eG');
  });

  it('uses exact BLZ lookup and rejects invalid BLZ', () => {
    expect(lookupBankByBlz('37040044', sampleBankDirectory).status).toBe('found');
    expect(lookupBankByBlz('3704004', sampleBankDirectory).status).toBe('invalid-blz');
  });
});
