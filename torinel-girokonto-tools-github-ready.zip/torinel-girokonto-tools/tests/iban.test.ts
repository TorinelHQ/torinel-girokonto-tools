import { describe, expect, it } from 'vitest';
import { extractGermanBlz, formatIban, isValidGermanIban, normalizeGermanIban, parseGermanIban } from '../src/iban';

describe('German IBAN helpers', () => {
  it('normalizes IBANs', () => {
    expect(normalizeGermanIban('de98 7016 9614 0000 0081 92')).toBe('DE98701696140000008192');
  });

  it('formats IBANs', () => {
    expect(formatIban('DE98701696140000008192')).toBe('DE98 7016 9614 0000 0081 92');
  });

  it('extracts BLZ from digits 5-12', () => {
    expect(extractGermanBlz('DE98 7016 9614 0000 0081 92')).toBe('70169614');
    expect(extractGermanBlz('DE35 7116 0000 0002 1583 53')).toBe('71160000');
    expect(extractGermanBlz('DE89 3704 0044 0532 0130 00')).toBe('37040044');
  });

  it('parses German IBAN parts', () => {
    expect(parseGermanIban('DE89 3704 0044 0532 0130 00')?.accountNumber).toBe('0532013000');
  });

  it('validates German IBAN checksum', () => {
    expect(isValidGermanIban('DE98 7016 9614 0000 0081 92')).toBe(true);
  });
});
