import type { BankCategory } from './types';

export function classifyBank(bankName: string): BankCategory {
  const name = bankName.toLowerCase();
  if (name.includes('sparkasse')) return 'sparkasse';
  if (name.includes('volksbank') || name.includes('vr bank')) return 'volksbank';
  if (name.includes('raiffeisen')) return 'raiffeisenbank';
  if (name.includes('sparda')) return 'sparda';
  if (name.includes('psd')) return 'psd';
  if (name.includes('dkb') || name.includes('ing') || name.includes('n26')) return 'direct-bank';
  if (name.includes('deutsche bank') || name.includes('commerzbank') || name.includes('postbank') || name.includes('targobank')) return 'national-bank';
  if (name.includes('bbbank') || name.includes('eg')) return 'cooperative-bank';
  return 'other';
}
