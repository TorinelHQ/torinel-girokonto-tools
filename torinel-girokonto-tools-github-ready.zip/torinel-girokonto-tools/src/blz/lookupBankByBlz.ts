import type { BankDirectoryRecord, BankLookupResult } from './types';

export function normalizeBlz(blz: string): string | null {
  const normalized = blz.replace(/\D+/g, '');
  return /^\d{8}$/.test(normalized) ? normalized : null;
}

export function createBankDirectoryIndex(records: BankDirectoryRecord[]): Map<string, BankDirectoryRecord> {
  const index = new Map<string, BankDirectoryRecord>();
  for (const record of records) {
    const blz = normalizeBlz(record.blz);
    if (!blz) continue;
    if (!index.has(blz)) {
      index.set(blz, { ...record, blz });
      continue;
    }
    const existing = index.get(blz)!;
    if (rank(record) > rank(existing)) index.set(blz, { ...record, blz });
  }
  return index;
}

export function lookupBankByBlz(blzInput: string, records: BankDirectoryRecord[]): BankLookupResult {
  const blz = normalizeBlz(blzInput);
  if (!blz) return { status: 'invalid-blz', blz: null };
  const record = createBankDirectoryIndex(records).get(blz);
  if (!record) return { status: 'not-found', blz };
  return { status: 'found', blz, record };
}

function rank(record: BankDirectoryRecord): number {
  const confidence = { official: 4, high: 3, medium: 2, manual: 1 }[record.confidence] ?? 0;
  const completeness = Number(Boolean(record.street)) + Number(Boolean(record.zip)) + Number(Boolean(record.city)) + Number(Boolean(record.bic));
  return confidence * 10 + completeness;
}
