import type { BankDirectoryRecord } from './types';

export const sampleBankDirectory: BankDirectoryRecord[] = [
  {
    blz: '37040044',
    bic: 'COBADEFFXXX',
    bankName: 'Commerzbank AG',
    street: 'Kaiserstraße 16',
    zip: '60261',
    city: 'Frankfurt am Main',
    category: 'national-bank',
    aliases: ['Commerzbank'],
    regional: false,
    confidence: 'manual',
    source: 'sample-data',
    lastUpdated: '2026-05-09'
  },
  {
    blz: '70169614',
    bic: 'GENODEF1FSR',
    bankName: 'Freisinger Bank eG',
    street: 'Untere Hauptstraße 34',
    zip: '85354',
    city: 'Freising',
    category: 'volksbank',
    aliases: ['Freisinger Bank', 'Volksbank Raiffeisenbank Freising'],
    regional: true,
    confidence: 'manual',
    source: 'sample-data',
    lastUpdated: '2026-05-09'
  },
  {
    blz: '71160000',
    bic: 'GENODEF1VRR',
    bankName: 'VR Bank Rosenheim-Chiemsee eG',
    street: 'Bahnhofstraße 5',
    zip: '83022',
    city: 'Rosenheim',
    category: 'volksbank',
    aliases: ['VR Bank Rosenheim-Chiemsee', 'Raiffeisenbank Rosenheim'],
    regional: true,
    confidence: 'manual',
    source: 'sample-data',
    lastUpdated: '2026-05-09'
  }
];
