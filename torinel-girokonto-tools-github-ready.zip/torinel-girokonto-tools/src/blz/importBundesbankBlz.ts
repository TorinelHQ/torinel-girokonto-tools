import { classifyBank } from './classifyBank';
import type { BankDirectoryRecord } from './types';

export type BundesbankImportOptions = {
  sourceLabel?: string;
  lastUpdated?: string;
};

/**
 * Converts a simplified Bundesbank-style export into Torinel's bank directory shape.
 *
 * This helper intentionally does not bundle official BLZ data. Feed it a parsed export
 * from the official Bundesbank BLZ directory, then validate the output before publishing.
 */
export function importBundesbankRows(
  rows: Array<Record<string, string | undefined>>,
  options: BundesbankImportOptions = {}
): BankDirectoryRecord[] {
  const source = options.sourceLabel ?? 'Bundesbank BLZ export';
  const lastUpdated = options.lastUpdated ?? new Date().toISOString().slice(0, 10);

  return rows
    .map(row => {
      const blz = pick(row, ['blz', 'bankleitzahl', 'Bankleitzahl', 'BLZ']);
      const bankName = pick(row, ['bankName', 'Bezeichnung', 'name', 'Bankname', 'Kurzbezeichnung']);
      if (!blz || !/^\d{8}$/.test(blz) || !bankName) return null;
      const record: BankDirectoryRecord = {
        blz,
        bic: pick(row, ['bic', 'BIC']) || undefined,
        bankName,
        street: pick(row, ['street', 'Straße', 'Strasse']) || undefined,
        zip: pick(row, ['zip', 'PLZ', 'Postleitzahl']) || undefined,
        city: pick(row, ['city', 'Ort']) || undefined,
        category: classifyBank(bankName),
        aliases: [bankName],
        regional: /sparkasse|volksbank|raiffeisen|vr bank|sparda|psd/i.test(bankName),
        confidence: 'official',
        source,
        lastUpdated
      };
      return record;
    })
    .filter((row): row is BankDirectoryRecord => Boolean(row));
}

function pick(row: Record<string, string | undefined>, keys: string[]): string | '' {
  for (const key of keys) {
    const value = row[key]?.trim();
    if (value) return value;
  }
  return '';
}
