export type BankCategory =
  | 'sparkasse'
  | 'volksbank'
  | 'raiffeisenbank'
  | 'sparda'
  | 'psd'
  | 'direct-bank'
  | 'national-bank'
  | 'cooperative-bank'
  | 'other';

export type BankDirectoryRecord = {
  blz: string;
  bic?: string;
  bankName: string;
  street?: string;
  zip?: string;
  city?: string;
  category: BankCategory;
  aliases: string[];
  regional: boolean;
  confidence: 'official' | 'high' | 'medium' | 'manual';
  source: string;
  lastUpdated: string;
};

export type BankLookupResult = {
  status: 'found' | 'not-found' | 'invalid-blz';
  blz: string | null;
  record?: BankDirectoryRecord;
};
