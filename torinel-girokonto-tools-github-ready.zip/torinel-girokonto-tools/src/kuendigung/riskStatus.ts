import type { RiskAssessment } from '../shared/riskStates';

export type CancellationRiskInput = {
  hasRemainingBalance?: boolean;
  hasStandingOrders?: boolean;
  hasDirectDebits?: boolean;
  hasOverdraft?: boolean;
  hasCreditCard?: boolean;
  isJointAccount?: boolean;
  hasSpecialCase?: boolean;
};

export function assessCancellationRisk(input: CancellationRiskInput): RiskAssessment {
  const red: string[] = [];
  const amber: string[] = [];

  if (input.hasOverdraft) red.push('Dispo oder negativer Kontostand vor der Kündigung klären.');
  if (input.hasSpecialCase) red.push('Sonderfall mit der Bank oder Beratung prüfen.');
  if (input.isJointAccount) amber.push('Zustimmung aller Kontoinhaber einholen.');
  if (input.hasDirectDebits) amber.push('Lastschriften vor Versand der Kündigung umstellen.');
  if (input.hasStandingOrders) amber.push('Daueraufträge prüfen und auf das neue Konto übertragen.');
  if (input.hasRemainingBalance) amber.push('Referenzkonto für Restguthaben angeben.');
  if (input.hasCreditCard) amber.push('Kreditkarte und Abrechnungskonto prüfen.');

  if (red.length) {
    return { state: 'red', label: 'Sonderfall prüfen', summary: 'Dieser Fall kann die Kontoschließung verzögern.', nextSteps: [...red, ...amber] };
  }

  if (amber.length) {
    return { state: 'amber', label: 'Noch zu prüfen', summary: 'Einige Punkte sollten vor der Kündigung geklärt werden.', nextSteps: amber };
  }

  return {
    state: 'green',
    label: 'Bereit zur Kündigung',
    summary: 'Keine Zusatzrisiken markiert. Prüfe trotzdem Zahlungspartner, Daueraufträge und Restguthaben.',
    nextSteps: ['Kündigungsschreiben erstellen.', 'Versandnachweis aufbewahren.', 'Schriftliche Bestätigung prüfen.']
  };
}
