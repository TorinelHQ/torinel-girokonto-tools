import { formatIban } from '../iban/normalizeGermanIban';
import type { BankDirectoryRecord } from '../blz/types';

export type CancellationLetterInput = {
  senderName: string;
  senderStreet: string;
  senderCityLine: string;
  iban: string;
  recipient: Pick<BankDirectoryRecord, 'bankName' | 'street' | 'zip' | 'city'>;
  location: string;
  date: string;
  referenceAccount?: string;
  requestWrittenConfirmation?: boolean;
};

export function generateCancellationLetter(input: CancellationLetterInput): string {
  const recipientCityLine = [input.recipient.zip, input.recipient.city].filter(Boolean).join(' ');
  const referenceAccount = input.referenceAccount?.trim();
  const confirmation = input.requestWrittenConfirmation === false
    ? ''
    : '\nBitte bestätigen Sie mir die Kontoschließung und die Übertragung des Restguthabens schriftlich.\n';

  return [
    input.senderName,
    input.senderStreet,
    input.senderCityLine,
    '',
    input.recipient.bankName,
    input.recipient.street ?? '',
    recipientCityLine,
    '',
    `${input.location}, ${input.date}`,
    '',
    `Betreff: Kündigung meines Girokontos, IBAN ${formatIban(input.iban)}`,
    '',
    'Sehr geehrte Damen und Herren,',
    '',
    `hiermit kündige ich mein Girokonto mit der IBAN ${formatIban(input.iban)} zum nächstmöglichen Zeitpunkt.`,
    '',
    'Meine Kontodaten:',
    `IBAN: ${formatIban(input.iban)}`,
    '',
    referenceAccount ? `Bitte überweisen Sie ein verbleibendes Restguthaben auf folgendes Referenzkonto:\n${formatIban(referenceAccount)}\n` : 'Bitte überweisen Sie ein verbleibendes Restguthaben auf mein angegebenes Referenzkonto.\n',
    'Bitte löschen Sie bestehende Daueraufträge zum Kündigungsdatum, sofern diese noch aktiv sind.',
    confirmation,
    'Mit freundlichen Grüßen',
    '',
    '',
    input.senderName
  ].filter(line => line !== undefined).join('\n');
}
