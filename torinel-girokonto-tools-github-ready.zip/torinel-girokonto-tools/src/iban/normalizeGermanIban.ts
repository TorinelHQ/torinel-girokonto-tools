export type GermanIbanParts = {
  country: 'DE';
  checkDigits: string;
  blz: string;
  accountNumber: string;
  normalized: string;
  formatted: string;
};

export function normalizeGermanIban(input: string): string {
  return input.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
}

export function formatIban(iban: string): string {
  return normalizeGermanIban(iban).replace(/(.{4})/g, '$1 ').trim();
}

export function extractGermanBlz(input: string): string | null {
  const iban = normalizeGermanIban(input);
  if (!/^DE\d{20}$/.test(iban)) return null;
  return iban.slice(4, 12);
}

export function parseGermanIban(input: string): GermanIbanParts | null {
  const normalized = normalizeGermanIban(input);
  if (!/^DE\d{20}$/.test(normalized)) return null;
  return {
    country: 'DE',
    checkDigits: normalized.slice(2, 4),
    blz: normalized.slice(4, 12),
    accountNumber: normalized.slice(12),
    normalized,
    formatted: formatIban(normalized)
  };
}
