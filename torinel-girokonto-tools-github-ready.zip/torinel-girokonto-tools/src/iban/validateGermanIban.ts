import { normalizeGermanIban } from './normalizeGermanIban';

function mod97(numeric: string): number {
  let remainder = 0;
  for (const char of numeric) {
    remainder = (remainder * 10 + Number(char)) % 97;
  }
  return remainder;
}

export function isValidGermanIban(input: string): boolean {
  const iban = normalizeGermanIban(input);
  if (!/^DE\d{20}$/.test(iban)) return false;
  const rearranged = iban.slice(4) + iban.slice(0, 4);
  const numeric = rearranged.replace(/[A-Z]/g, char => String(char.charCodeAt(0) - 55));
  return mod97(numeric) === 1;
}
