import type { RiskAssessment } from '../shared/riskStates';

export type WechselItemKey =
  | 'newAccountActive'
  | 'salaryUpdated'
  | 'standingOrdersMoved'
  | 'directDebitsChecked'
  | 'digitalPaymentsUpdated'
  | 'cardsChecked'
  | 'overdraftCleared'
  | 'statementsSaved'
  | 'parallelRunObserved'
  | 'remainingBalanceTransferred'
  | 'cancellationLetterPrepared';

export type WechselChecklist = Partial<Record<WechselItemKey, boolean>>;

const itemWeights: Record<WechselItemKey, number> = {
  newAccountActive: 15,
  salaryUpdated: 15,
  standingOrdersMoved: 12,
  directDebitsChecked: 15,
  digitalPaymentsUpdated: 10,
  cardsChecked: 8,
  overdraftCleared: 8,
  statementsSaved: 6,
  parallelRunObserved: 8,
  remainingBalanceTransferred: 8,
  cancellationLetterPrepared: 3
};

const missingStepCopy: Record<WechselItemKey, string> = {
  newAccountActive: 'Neues Konto aktivieren und erste Testzahlung prüfen.',
  salaryUpdated: 'Arbeitgeber und andere Zahlungseingänge über die neue IBAN informieren.',
  standingOrdersMoved: 'Daueraufträge neu einrichten und alte Aufträge erst nach erfolgreicher Ausführung löschen.',
  directDebitsChecked: 'Lastschriften und Zahlungspartner der letzten Monate prüfen.',
  digitalPaymentsUpdated: 'PayPal, Wallets, Online-Shops und Abos auf die neue Bankverbindung umstellen.',
  cardsChecked: 'Karten, Kreditkartenabrechnungen und verknüpfte Produkte prüfen.',
  overdraftCleared: 'Dispo oder negativen Kontostand ausgleichen.',
  statementsSaved: 'Kontoauszüge und wichtige Online-Postfach-Dokumente sichern.',
  parallelRunObserved: 'Altes und neues Konto eine Übergangszeit parallel beobachten.',
  remainingBalanceTransferred: 'Restguthaben auf das neue Konto übertragen.',
  cancellationLetterPrepared: 'Kündigungsschreiben vorbereiten, sobald der Wechsel abgeschlossen ist.'
};

export function scoreWechselReadiness(checklist: WechselChecklist): RiskAssessment & { score: number } {
  const score = Object.entries(itemWeights).reduce((total, [key, weight]) => {
    return total + (checklist[key as WechselItemKey] ? weight : 0);
  }, 0);

  const missing = (Object.keys(itemWeights) as WechselItemKey[])
    .filter(key => !checklist[key])
    .map(key => missingStepCopy[key]);

  if (score === 0) {
    return {
      score,
      state: 'neutral',
      label: 'Noch nicht geprüft',
      summary: 'Beantworte die Checkliste, um deinen Wechselstatus einzuschätzen.',
      nextSteps: missing.slice(0, 4)
    };
  }

  if (score < 55) {
    return {
      score,
      state: 'red',
      label: 'Noch nicht kündigen',
      summary: 'Es fehlen noch wichtige Schritte. Kündige das alte Konto erst, wenn die kritischen Zahlungen umgestellt sind.',
      nextSteps: missing.slice(0, 5)
    };
  }

  if (score < 85) {
    return {
      score,
      state: 'amber',
      label: 'Fast bereit',
      summary: 'Der Wechsel ist weit fortgeschritten. Prüfe die offenen Punkte, bevor du das alte Konto schließt.',
      nextSteps: missing.slice(0, 4)
    };
  }

  return {
    score,
    state: 'green',
    label: 'Kündigungsbereit',
    summary: 'Die wichtigsten Wechselpunkte sind erledigt. Du kannst die Kündigung des alten Kontos vorbereiten.',
    nextSteps: missing.slice(0, 3)
  };
}
