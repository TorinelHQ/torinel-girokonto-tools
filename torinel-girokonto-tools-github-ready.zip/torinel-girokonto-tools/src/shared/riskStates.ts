export type RiskState = 'neutral' | 'green' | 'amber' | 'red';

export type RiskAssessment = {
  state: RiskState;
  label: string;
  summary: string;
  nextSteps: string[];
};
