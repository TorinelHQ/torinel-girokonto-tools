import { extractGermanBlz, formatIban } from '../src/iban';
import { lookupBankByBlz, sampleBankDirectory } from '../src/blz';
import { generateCancellationLetter } from '../src/kuendigung';

const iban = 'DE98 7016 9614 0000 0081 92';
const blz = extractGermanBlz(iban);
if (!blz) throw new Error('Invalid German IBAN');

const lookup = lookupBankByBlz(blz, sampleBankDirectory);
if (lookup.status !== 'found') throw new Error(`No bank found for BLZ ${blz}`);

console.log(`IBAN: ${formatIban(iban)}`);
console.log(`BLZ: ${blz}`);
console.log(`Bank: ${lookup.record.bankName}`);

console.log(generateCancellationLetter({
  senderName: 'Max Mustermann',
  senderStreet: 'Musterstraße 1',
  senderCityLine: '12345 Musterstadt',
  iban,
  recipient: lookup.record,
  location: 'Musterstadt',
  date: '09.05.2026',
  referenceAccount: 'DE89370400440532013000'
}));
