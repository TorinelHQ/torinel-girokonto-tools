import { scoreWechselReadiness } from '../src/wechsel';

const result = scoreWechselReadiness({
  newAccountActive: true,
  salaryUpdated: true,
  standingOrdersMoved: true,
  directDebitsChecked: false,
  digitalPaymentsUpdated: false,
  statementsSaved: true
});

console.log(result.label);
console.log(result.summary);
console.log(result.nextSteps);
