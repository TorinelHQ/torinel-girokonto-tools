# Girokonto-Kündigungsassistent methodology

The cancellation assistant helps users prepare a neutral German cancellation letter.

## Workflow

1. User enters a German IBAN
2. The IBAN is normalized and validated
3. The BLZ is extracted
4. The bank recipient is resolved by exact BLZ lookup
5. The user completes sender and risk details
6. The assistant generates a printable German letter

## Letter principles

The generated letter should be:

- neutral
- printable
- German business-letter style
- free of Torinel branding
- free of marketing copy
- clear about IBAN and recipient

## Risk logic

The assistant flags issues such as:

- Restguthaben
- Daueraufträge
- Lastschriften
- Dispo/Kredit
- Kreditkarte
- Gemeinschaftskonto
- Sonderfälle

The goal is not only to create a letter, but to reduce the chance of payment problems after cancellation.
