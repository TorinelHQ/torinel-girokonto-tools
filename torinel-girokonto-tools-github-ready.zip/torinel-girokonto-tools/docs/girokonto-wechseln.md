# Girokonto-Wechsel-Check methodology

The Wechsel-Check estimates whether a user is ready to close the old Girokonto after switching to a new account.

## Core idea

A Girokonto should not be cancelled just because a new account exists. The important question is whether income, debits, standing orders, digital payments, cards, and documents have been handled.

## Readiness states

- neutral: no meaningful answers yet
- red: do not cancel yet
- amber: almost ready, check open items
- green: ready to prepare cancellation

## Typical checklist items

- new account active
- salary or main income updated
- standing orders moved
- direct debits checked
- PayPal, wallets, subscriptions updated
- cards and credit-card settlement checked
- overdraft cleared
- statements saved
- old and new account observed in parallel
- remaining balance transferred
- cancellation letter prepared

The result should generate practical next steps, not just a score.
