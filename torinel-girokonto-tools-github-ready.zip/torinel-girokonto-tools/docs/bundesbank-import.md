# Bundesbank BLZ import notes

This repository contains an importer for turning a parsed Bundesbank BLZ export into Torinel's bank directory record shape.

It does not bundle the official BLZ directory.

## Recommended process

1. Download the current official BLZ directory from Bundesbank.
2. Parse the export into rows.
3. Run `importBundesbankRows`.
4. Validate record completeness.
5. Deduplicate by exact BLZ.
6. Prefer official/current records.
7. Run regression tests for known IBANs and banks.

## Record shape

Each bank record should include:

- blz
- bic
- bankName
- street
- zip
- city
- category
- aliases
- regional
- confidence
- source
- lastUpdated

## Integrity rule

An exact BLZ hit must never be overwritten by fuzzy bank-name inference.
