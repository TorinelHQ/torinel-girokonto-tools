# IBAN to BLZ lookup methodology

Torinel's Girokonto cancellation workflow uses deterministic BLZ lookup.

## German IBAN rule

A German IBAN has this structure:

```text
DEkk BBBBBBBB CCCCCCCCCC
```

- `DE` = country code
- `kk` = check digits
- `BBBBBBBB` = BLZ
- `CCCCCCCCCC` = account number

The lookup must use the extracted BLZ, not a fuzzy bank-name guess.

## Required order

1. Remove spaces and separators
2. Uppercase the IBAN
3. Confirm German IBAN shape: `DE` + 20 digits
4. Extract digits 5–12 as BLZ
5. Run exact BLZ lookup
6. Return the canonical bank record

## Why exact lookup matters

Many German banks have regional structures, mergers, or similar names. A generic name such as Sparkasse, Volksbank, or Raiffeisenbank is not enough to choose the correct recipient.

The correct result should be based on the BLZ extracted from the IBAN.
